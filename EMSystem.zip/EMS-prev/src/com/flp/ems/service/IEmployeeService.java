package com.flp.ems.service;

import java.util.HashMap;
import java.util.List;

import com.flp.ems.domain.Employee;

public interface IEmployeeService {

	public boolean AddEmployee(HashMap<String , String > h);
	public boolean ModifyEmployee(HashMap<String , String > h);
	public boolean RemoveEmployee(HashMap<String , String > h);
	public boolean SearchEmployee(HashMap<String , String > h);
	public HashMap<String,String>[] getAllEmployee();
}
