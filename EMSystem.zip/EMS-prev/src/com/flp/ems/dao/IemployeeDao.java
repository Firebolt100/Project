package com.flp.ems.dao;

import java.util.List;

import com.flp.ems.domain.Employee;

public interface IemployeeDao {

	public boolean AddEmployee(Employee employee);
	public boolean ModifyEmployee(Employee employee);
	public boolean RemoveEmployee(Employee employee);
	public boolean SearchEmployee(Employee employee);
	public List<Employee> getAllEmployee();
}
